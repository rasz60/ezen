package com.ezen.mini.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ezen.mini.dao.MiniDao;

public class Constant {

	public static MiniDao mdao;
	public static BCryptPasswordEncoder passwordEncoder;
}
